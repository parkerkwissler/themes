<?php
/*
Plugin Name: IB Retina
Description: Creates 2x images for image uploads.
Author: dmytro.d (IncredibleBytes)
Version: 1.0.0
Author URI: http://incrediblebytes.com
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: ib-retina
*/

define( 'IB_RETINA_URL', plugins_url( '', __FILE__ ) );

require_once 'include/ib-retina.php';
IB_Retina::init();

if ( is_admin() ) {
	require_once 'include/ib-retina-admin.php';
	IB_Retina_Admin::init();
}