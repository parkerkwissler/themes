<?php

class IBFW_User {
	/**
	 * @access public
	 * @var IBFW_User
	 */
	private static $instance;

	/**
	 * Private constructor.
	 */
	private function __construct() {}

	/**
	 * Get instance.
	 *
	 * @return IBFW_User
	 */
	public static function get_instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Update current user data from $_POST.
	 *
	 * @return array|int
	 */
	public function update_profile() {
		if ( empty( $_POST ) ) {
			return;
		}

		// Get current user.
		$curauth = wp_get_current_user();
		if ( ! $curauth->ID ) return;

		$user_data = array();
		$errors = array();

		if ( isset( $_POST['first_name'] ) ) {
			$user_data['first_name'] = $_POST['first_name'];
		}

		if ( isset( $_POST['last_name'] ) ) {
			$user_data['last_name'] = $_POST['last_name'];
		}

		if ( isset( $_POST['user_email'] ) ) {
			if ( ! is_email( $_POST['user_email'] ) ) {
				$errors[] = 'email_invalid';
			} elseif ( $_POST['user_email'] != $curauth->user_email && email_exists( $_POST['user_email'] ) ) {
				$errors[] = 'email_exists';
			} else {
				$user_data['user_email'] = $_POST['user_email'];
			}
		}

		if ( isset( $_POST['description'] ) ) {
			$user_data['description'] = $_POST['description'];
		}

		if ( ! empty( $_POST['user_pass'] ) ) {
			if ( strlen( $_POST['user_pass'] ) < 6 ) {
				$errors[] = 'short_password';
			} elseif ( ! isset( $_POST['user_pass_2'] ) || $_POST['user_pass_2'] != $_POST['user_pass'] ) {
				$errors[] = 'passwords_no_match';
			} else {
				$user_data['user_pass'] = $_POST['user_pass'];
			}
		}
		
		if ( ! count( $errors ) ) {
			$user_data['ID'] = get_current_user_id();
			$user_id = wp_update_user( $user_data );

			if ( ! is_wp_error( $user_id ) ) {
				return $user_id;
			} else {
				return $user_id->get_error_codes();
			}
		} else {
			return $errors;
		}
	}
}